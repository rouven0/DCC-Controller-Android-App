package com.traincon.modelleisenbahn_controller;

import java.net.Socket;
import java.util.Arrays;

public class BoardManager {
    public final int[] switchStates = new int[16];
    public final int[] sectionStates = new int[13];
    public int lightState = 0;

    public Socket mainSocket;

    public BoardManager(){
        Arrays.fill(switchStates, 0);
        Arrays.fill(sectionStates, 0);
    }


    public void connect(String host, int port){

    }
}
